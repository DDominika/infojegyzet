﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Fuvar
{
    class Program
    {
        static void Main(string[] args)
        {
            /*BEOLVASÁS*/
            List<adatok> tarol = new List<adatok>(); //lista
            foreach (var item in File.ReadAllLines("fuvar.csv",Encoding.UTF8).Skip(1)) //az első sort kihagyja
            {
                tarol.Add(new adatok(item)); //hozzá adja a listához 
            }
            string fejlec = File.ReadLines("fuvar.csv").First();
            //3. feladat
            Console.WriteLine("3. feladat: {0} fuvar", tarol.Count);

            //4.feladat
            float bevetel = 0;
            int fuvar = 0;
            for (int i = 0; i < tarol.Count; i++)
            {
                if (tarol[i].taxi_id == 6185)
                {
                    fuvar++;
                    bevetel += tarol[i].viteldij + tarol[i].borravalo;
                }
            }
            Console.WriteLine($"4.feladat: {fuvar} fuvar alatt: {bevetel}$");

            //5.feladat
            Console.WriteLine("5.feladat:");
            foreach (var item in tarol.GroupBy(x=>x.fiz_mod))
            {
                Console.WriteLine("\t{0}: {1} fuvar",item.Key, item.Count());
            }
            //6.feladat
            double km = 0;
            for (int i = 0; i < tarol.Count; i++)
            {
                if (tarol[i].tavolsag>0)
                {
                    km += tarol[i].tavolsag;
                }
            }
            Console.WriteLine("6.feladat: {0:#.##}km",km*1.6);

            //7. feladat
            adatok max = tarol[0]; //objektum
            foreach (var item in tarol)
            {
                if (max.idotartam < item.idotartam)
                {
                    max = item;
                }
            }
            Console.WriteLine($"7.feladat: Leghosszabb fuvar:\n\tFuvar hossza: {max.idotartam} másodperc\n\tTaxi azonosító: {max.taxi_id}\n\tMegtett távolság: {max.tavolsag}km\n\tViteldíj: {max.viteldij}$");

            //8.feladat
            StreamWriter kiir = new StreamWriter("hibak.txt",false,Encoding.UTF8);
            kiir.WriteLine(fejlec); //fent van létrehozva, a streamreader alatt
            foreach (var item in tarol.OrderBy(x=>x.indulas))
            {
                if (item.idotartam > 0 && item.viteldij > 0 && item.tavolsag == 0)
                {
                    kiir.WriteLine($"{item.taxi_id};{item.indulas};{item.idotartam};{item.tavolsag};{item.viteldij};{item.borravalo};{item.fiz_mod};");
                }
            }
            kiir.Close();
            Console.WriteLine("8.feladat: hibak.txt");

            Console.ReadKey();
        }

    }
}
