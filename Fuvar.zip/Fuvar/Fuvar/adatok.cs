﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fuvar
{
    class adatok
    {
        //ADATOK
        public int taxi_id { get; private set; }
        public DateTime indulas { get; private set; }
        public int idotartam { get; private set; }
        public float tavolsag { get; private set; }
        public float viteldij { get; private set; }
        public float borravalo { get; private set; }
        public string fiz_mod { get; private set; }

        //KONSTRUKTOR
        public adatok(string sor)
        {
            string[] darabol = sor.Split(';'); //darabolás soronként
            taxi_id = int.Parse(darabol[0]);
            indulas = DateTime.Parse(darabol[1]);
            idotartam = int.Parse(darabol[2]);
            tavolsag = float.Parse(darabol[3]);
            viteldij = float.Parse(darabol[4]);
            borravalo = float.Parse(darabol[5]);
            fiz_mod = darabol[6];
        }
       
    }
}
